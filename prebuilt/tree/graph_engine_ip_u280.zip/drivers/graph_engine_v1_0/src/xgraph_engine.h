// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.2 (64-bit)
// Tool Version Limit: 2023.10
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XGRAPH_ENGINE_H
#define XGRAPH_ENGINE_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xgraph_engine_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
} XGraph_engine_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XGraph_engine;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XGraph_engine_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XGraph_engine_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XGraph_engine_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XGraph_engine_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XGraph_engine_Initialize(XGraph_engine *InstancePtr, UINTPTR BaseAddress);
XGraph_engine_Config* XGraph_engine_LookupConfig(UINTPTR BaseAddress);
#else
int XGraph_engine_Initialize(XGraph_engine *InstancePtr, u16 DeviceId);
XGraph_engine_Config* XGraph_engine_LookupConfig(u16 DeviceId);
#endif
int XGraph_engine_CfgInitialize(XGraph_engine *InstancePtr, XGraph_engine_Config *ConfigPtr);
#else
int XGraph_engine_Initialize(XGraph_engine *InstancePtr, const char* InstanceName);
int XGraph_engine_Release(XGraph_engine *InstancePtr);
#endif

void XGraph_engine_Start(XGraph_engine *InstancePtr);
u32 XGraph_engine_IsDone(XGraph_engine *InstancePtr);
u32 XGraph_engine_IsIdle(XGraph_engine *InstancePtr);
u32 XGraph_engine_IsReady(XGraph_engine *InstancePtr);
void XGraph_engine_Continue(XGraph_engine *InstancePtr);
void XGraph_engine_EnableAutoRestart(XGraph_engine *InstancePtr);
void XGraph_engine_DisableAutoRestart(XGraph_engine *InstancePtr);

void XGraph_engine_Set_seed_in(XGraph_engine *InstancePtr, u64 Data);
u64 XGraph_engine_Get_seed_in(XGraph_engine *InstancePtr);
void XGraph_engine_Set_state_out(XGraph_engine *InstancePtr, u64 Data);
u64 XGraph_engine_Get_state_out(XGraph_engine *InstancePtr);
void XGraph_engine_Set_num_steps(XGraph_engine *InstancePtr, u32 Data);
u32 XGraph_engine_Get_num_steps(XGraph_engine *InstancePtr);
void XGraph_engine_Set_active_trace(XGraph_engine *InstancePtr, u64 Data);
u64 XGraph_engine_Get_active_trace(XGraph_engine *InstancePtr);

void XGraph_engine_InterruptGlobalEnable(XGraph_engine *InstancePtr);
void XGraph_engine_InterruptGlobalDisable(XGraph_engine *InstancePtr);
void XGraph_engine_InterruptEnable(XGraph_engine *InstancePtr, u32 Mask);
void XGraph_engine_InterruptDisable(XGraph_engine *InstancePtr, u32 Mask);
void XGraph_engine_InterruptClear(XGraph_engine *InstancePtr, u32 Mask);
u32 XGraph_engine_InterruptGetEnabled(XGraph_engine *InstancePtr);
u32 XGraph_engine_InterruptGetStatus(XGraph_engine *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
