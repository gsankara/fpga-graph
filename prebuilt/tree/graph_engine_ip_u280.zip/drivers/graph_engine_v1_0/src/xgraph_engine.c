// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.2 (64-bit)
// Tool Version Limit: 2023.10
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xgraph_engine.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XGraph_engine_CfgInitialize(XGraph_engine *InstancePtr, XGraph_engine_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XGraph_engine_Start(XGraph_engine *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XGraph_engine_ReadReg(InstancePtr->Control_BaseAddress, XGRAPH_ENGINE_CONTROL_ADDR_AP_CTRL) & 0x80;
    XGraph_engine_WriteReg(InstancePtr->Control_BaseAddress, XGRAPH_ENGINE_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XGraph_engine_IsDone(XGraph_engine *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XGraph_engine_ReadReg(InstancePtr->Control_BaseAddress, XGRAPH_ENGINE_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XGraph_engine_IsIdle(XGraph_engine *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XGraph_engine_ReadReg(InstancePtr->Control_BaseAddress, XGRAPH_ENGINE_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XGraph_engine_IsReady(XGraph_engine *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XGraph_engine_ReadReg(InstancePtr->Control_BaseAddress, XGRAPH_ENGINE_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XGraph_engine_Continue(XGraph_engine *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XGraph_engine_ReadReg(InstancePtr->Control_BaseAddress, XGRAPH_ENGINE_CONTROL_ADDR_AP_CTRL) & 0x80;
    XGraph_engine_WriteReg(InstancePtr->Control_BaseAddress, XGRAPH_ENGINE_CONTROL_ADDR_AP_CTRL, Data | 0x10);
}

void XGraph_engine_EnableAutoRestart(XGraph_engine *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XGraph_engine_WriteReg(InstancePtr->Control_BaseAddress, XGRAPH_ENGINE_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XGraph_engine_DisableAutoRestart(XGraph_engine *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XGraph_engine_WriteReg(InstancePtr->Control_BaseAddress, XGRAPH_ENGINE_CONTROL_ADDR_AP_CTRL, 0);
}

void XGraph_engine_Set_seed_in(XGraph_engine *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XGraph_engine_WriteReg(InstancePtr->Control_BaseAddress, XGRAPH_ENGINE_CONTROL_ADDR_SEED_IN_DATA, (u32)(Data));
    XGraph_engine_WriteReg(InstancePtr->Control_BaseAddress, XGRAPH_ENGINE_CONTROL_ADDR_SEED_IN_DATA + 4, (u32)(Data >> 32));
}

u64 XGraph_engine_Get_seed_in(XGraph_engine *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XGraph_engine_ReadReg(InstancePtr->Control_BaseAddress, XGRAPH_ENGINE_CONTROL_ADDR_SEED_IN_DATA);
    Data += (u64)XGraph_engine_ReadReg(InstancePtr->Control_BaseAddress, XGRAPH_ENGINE_CONTROL_ADDR_SEED_IN_DATA + 4) << 32;
    return Data;
}

void XGraph_engine_Set_state_out(XGraph_engine *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XGraph_engine_WriteReg(InstancePtr->Control_BaseAddress, XGRAPH_ENGINE_CONTROL_ADDR_STATE_OUT_DATA, (u32)(Data));
    XGraph_engine_WriteReg(InstancePtr->Control_BaseAddress, XGRAPH_ENGINE_CONTROL_ADDR_STATE_OUT_DATA + 4, (u32)(Data >> 32));
}

u64 XGraph_engine_Get_state_out(XGraph_engine *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XGraph_engine_ReadReg(InstancePtr->Control_BaseAddress, XGRAPH_ENGINE_CONTROL_ADDR_STATE_OUT_DATA);
    Data += (u64)XGraph_engine_ReadReg(InstancePtr->Control_BaseAddress, XGRAPH_ENGINE_CONTROL_ADDR_STATE_OUT_DATA + 4) << 32;
    return Data;
}

void XGraph_engine_Set_num_steps(XGraph_engine *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XGraph_engine_WriteReg(InstancePtr->Control_BaseAddress, XGRAPH_ENGINE_CONTROL_ADDR_NUM_STEPS_DATA, Data);
}

u32 XGraph_engine_Get_num_steps(XGraph_engine *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XGraph_engine_ReadReg(InstancePtr->Control_BaseAddress, XGRAPH_ENGINE_CONTROL_ADDR_NUM_STEPS_DATA);
    return Data;
}

void XGraph_engine_Set_active_trace(XGraph_engine *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XGraph_engine_WriteReg(InstancePtr->Control_BaseAddress, XGRAPH_ENGINE_CONTROL_ADDR_ACTIVE_TRACE_DATA, (u32)(Data));
    XGraph_engine_WriteReg(InstancePtr->Control_BaseAddress, XGRAPH_ENGINE_CONTROL_ADDR_ACTIVE_TRACE_DATA + 4, (u32)(Data >> 32));
}

u64 XGraph_engine_Get_active_trace(XGraph_engine *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XGraph_engine_ReadReg(InstancePtr->Control_BaseAddress, XGRAPH_ENGINE_CONTROL_ADDR_ACTIVE_TRACE_DATA);
    Data += (u64)XGraph_engine_ReadReg(InstancePtr->Control_BaseAddress, XGRAPH_ENGINE_CONTROL_ADDR_ACTIVE_TRACE_DATA + 4) << 32;
    return Data;
}

void XGraph_engine_InterruptGlobalEnable(XGraph_engine *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XGraph_engine_WriteReg(InstancePtr->Control_BaseAddress, XGRAPH_ENGINE_CONTROL_ADDR_GIE, 1);
}

void XGraph_engine_InterruptGlobalDisable(XGraph_engine *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XGraph_engine_WriteReg(InstancePtr->Control_BaseAddress, XGRAPH_ENGINE_CONTROL_ADDR_GIE, 0);
}

void XGraph_engine_InterruptEnable(XGraph_engine *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XGraph_engine_ReadReg(InstancePtr->Control_BaseAddress, XGRAPH_ENGINE_CONTROL_ADDR_IER);
    XGraph_engine_WriteReg(InstancePtr->Control_BaseAddress, XGRAPH_ENGINE_CONTROL_ADDR_IER, Register | Mask);
}

void XGraph_engine_InterruptDisable(XGraph_engine *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XGraph_engine_ReadReg(InstancePtr->Control_BaseAddress, XGRAPH_ENGINE_CONTROL_ADDR_IER);
    XGraph_engine_WriteReg(InstancePtr->Control_BaseAddress, XGRAPH_ENGINE_CONTROL_ADDR_IER, Register & (~Mask));
}

void XGraph_engine_InterruptClear(XGraph_engine *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XGraph_engine_WriteReg(InstancePtr->Control_BaseAddress, XGRAPH_ENGINE_CONTROL_ADDR_ISR, Mask);
}

u32 XGraph_engine_InterruptGetEnabled(XGraph_engine *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XGraph_engine_ReadReg(InstancePtr->Control_BaseAddress, XGRAPH_ENGINE_CONTROL_ADDR_IER);
}

u32 XGraph_engine_InterruptGetStatus(XGraph_engine *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XGraph_engine_ReadReg(InstancePtr->Control_BaseAddress, XGRAPH_ENGINE_CONTROL_ADDR_ISR);
}

