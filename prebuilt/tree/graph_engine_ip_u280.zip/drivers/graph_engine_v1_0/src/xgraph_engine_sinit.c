// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.2 (64-bit)
// Tool Version Limit: 2023.10
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xgraph_engine.h"

extern XGraph_engine_Config XGraph_engine_ConfigTable[];

#ifdef SDT
XGraph_engine_Config *XGraph_engine_LookupConfig(UINTPTR BaseAddress) {
	XGraph_engine_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XGraph_engine_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XGraph_engine_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XGraph_engine_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XGraph_engine_Initialize(XGraph_engine *InstancePtr, UINTPTR BaseAddress) {
	XGraph_engine_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XGraph_engine_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XGraph_engine_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XGraph_engine_Config *XGraph_engine_LookupConfig(u16 DeviceId) {
	XGraph_engine_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XGRAPH_ENGINE_NUM_INSTANCES; Index++) {
		if (XGraph_engine_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XGraph_engine_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XGraph_engine_Initialize(XGraph_engine *InstancePtr, u16 DeviceId) {
	XGraph_engine_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XGraph_engine_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XGraph_engine_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

